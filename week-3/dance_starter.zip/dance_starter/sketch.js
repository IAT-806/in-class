// IAT 806 · Arrays, loops, functions
// One dancer, built up one complaint at a time.
// Run with Live Server (opening index.html from disk blocks image loading).

let img;

async function setup() {
  createCanvas(400, 400);
  img = await loadImage('dance_frames/dance0.png');
}

function draw() {
  background(240);
  image(img, 70, 40);
}

// ---------------------------------------------------------------
// STEP 1  One image. Break it first: delete `await`, read the error.
// STEP 2  "I have 8 frames."  -> array, frames[0], click to advance,
//         click past the end, fix with .length or %
// STEP 3  "I'm typing 8 filenames." -> load in a loop:
//         'dance_frames/dance' + i + '.png'
//         then a contact sheet: image(frames[i], i * w, 0)
// STEP 4  Animate: frames[frameCount % frames.length]  (blur!)
//         then floor(frameCount / speed) % frames.length
// STEP 5  "Two dancers, different speeds." -> animate(frames, x, y, speed)
//         Run it uncalled (blank canvas), then call it twice.
// STEP 6  currentFrame(frames, speed) RETURNS an image.
//         Compare with animate(), which DRAWS.
// STEP 7  Parallel arrays xs[] and speeds[] ... then admit it hurts.
//         (Week 4: classes.)
// ---------------------------------------------------------------
